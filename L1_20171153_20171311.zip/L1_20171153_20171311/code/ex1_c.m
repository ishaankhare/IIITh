X1 = randn(1,10000);
X2 = randn(1,10000);
X3 = randn(1,10000);
disp(X1(19));
disp(X2(11));
disp(X3(100));

um = X1+ X2 + X3;
um1 = X1(19) + X2(11) + X3(100);

X = um1/3;
disp(X);

V = ((X - X1(19)).^2 + (X-X2(11)).^2 + (X-X3(100)).^2)/3;
disp(V);
histogram(um);