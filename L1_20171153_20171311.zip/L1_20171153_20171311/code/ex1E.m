





Y = randn(1, 10000);
X = randn(1, 10000);

U = sqrt(X.^2 + Y.^2);
histogram(U);