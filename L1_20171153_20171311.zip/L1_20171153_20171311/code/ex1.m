uni_num = rand(1,10000);
nor_num = randn(1,10000);
histogram(uni_num);
figure;
histogram(nor_num);

Y= sum(uni_num);
X = Y/10000;
disp(X);

Y1 = sum(nor_num);
X1 = Y1/10000;
disp(X1);

W = 0;
U = 0;
W1 = 0;
U1 = 0;
for i = 1:length(uni_num)
        W = (uni_num(i) - X).^2;
        U = U + W;
        
end

for j = 1:length(nor_num)
    W1 = (nor_num(j) - X1).^2;
    U1 = U1 + W1;
end

A = U/10000;
A1 = U1/10000;
disp(A);
disp(A1);


