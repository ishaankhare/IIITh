uni = rand(1, 10000);
U = 1 - uni;
Q = log(U);
E = Q*(-1);
histogram(E);
