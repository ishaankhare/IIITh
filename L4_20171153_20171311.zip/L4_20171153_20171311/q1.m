%%
M = 51;
re = ones(1 , M);
figure(1);
plot(re);
rec = abs(fftshift(fft(re, 1000)));
figure(2);
plot(20*log10(rec));


%%
bar = bartlett(M);
figure(1);
plot(bar);
ba = abs(fftshift(fft(bar, 1000)));
figure(2);
plot(20*log10(ba));

%%
ham = hamming(M);
figure(1);
plot(ham);
ha = abs(fftshift(fft(ham, 1000)));
figure(2);
plot(ha);
plot(20*log10(ha));

%%
bla = blackman(M);
figure(1);
plot(bla);
bl = abs(fftshift(fft(bla, 1000)));
figure(2);
plot(20*log10(bl));

%%
kai = kaiser(M, 0.5);
figure(1);
plot(kai);
ka = abs(fftshift(fft(kai, 1000)));
figure(2);

plot(20*log10(ka));
%%
Wc = 2*pi*8/20;
k = (M-1)/2;
x = zeros(1, M);
recf = zeros(1, M);
barf = zeros(1, M);
hamf = zeros(1, M);
blaf = zeros(1, M);
kaif = zeros(1, M);
for n=1:M
x(n) = sin(Wc*(n-k))/(pi*(n-k));
recf(n) = x(n) * rec(n);
barf(n) = x(n) * bar(n);
hamf(n) = x(n) * ham(n);
blaf(n) = x(n) * bla(n);
kaif(n) = x(n) * kai(n);
if isequal(n , k)
    recf(n) = 1;
    barf(n) = 1;
    hamf(n) = 1;
    blaf(n) = 1;
    kaif(n) = 1;
end    
end
plot(abs(fftshift(fft(recf))));
%plot(recf);
%%
fc = 8000;
a = sin(2*pi*(fc-1000));
b = sin(2*pi*(fc+1000));
c = a+b;
a1 = conv(c, recf);
b1 = conv(c, barf);
c1 = conv(c, hamf);
d1 = conv(c, blaf);
e1 = conv(c, kaif);
plot(abs(fftshift(fft(a1))));






