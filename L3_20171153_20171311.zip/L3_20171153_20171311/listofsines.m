function x2 = listofsines( N, A2, F2, phi2, Tv, Fs)
    x2=0;
    t = 0:1/Fs:Tv;
    for c=1:N 
    l = A2(c)*sin((2*pi*F2(c)*c*t) + phi2(c));    
    x2 = [x2,l];
    end
end