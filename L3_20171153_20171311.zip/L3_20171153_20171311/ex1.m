%%
a = 10;
f = 3000;
phi = 0;
T = 2;
Fs = 48000;
x = sinusoid(a, f, phi, T, Fs);
plot(x);
sound(x, Fs);
p = abs(fft(x));
%figure(1);
%plot(p);
win = hamming(0.1*48000);
spectrogram(x, win, 0,0:10:5000, 48000, 'yaxis');
%%
K = 5;
A = randn(K,1);
phase = randn(K,1);
y2 = sumofharmonics(K, A, f, phase, T, Fs);
sound(y2, Fs);
plot(y2);

win = hamming(0.1*48000);
spectrogram(y2, win, 0,0:10:20000, 48000, 'yaxis');
%%
phi1 = randn(K, 1);
A1 = randn(K, 1);
f1 = rand(K, 1)*10000;

x1 = sumofsines(K, A1, f1, phi1, T, Fs);  
sound(x1, Fs);
%plot(x1);
win = hamming(0.1*48000);
spectrogram(x1, win, 0,0:10:2000, 48000, 'yaxis');

%%
N = 4;
Tv = 2;

phi2 = randn(N, 1);
A2 = randn(N, 1);
F2 = rand(N, 1)*10000;

x2 =  listofsines(N, A2, F2, phi2, Tv, Fs);
sound(x2,Fs);
plot(x2);
win = hamming(0.1*48000);
spectrogram(x2, win, 0,0:10:25000, 48000, 'yaxis');
%%













