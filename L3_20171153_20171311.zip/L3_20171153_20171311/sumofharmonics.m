function y2 = sumofharmonics(K, A, f, phase, T, Fs)
    y2 = 0;
    for i=1:K
        y2 = sinusoid(A(i), f, phase(i), T, Fs) + y2;
    end
end