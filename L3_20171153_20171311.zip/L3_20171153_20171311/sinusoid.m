function x = sinusoid(a, f, phi, T, Fs)
   n = T * Fs;
   for i=1:n
       x(i) = a*sin((2*pi*f*i/Fs) + phi);
   end
end