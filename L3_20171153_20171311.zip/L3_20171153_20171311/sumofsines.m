function x1 = sumofsines(K, A1, f1, phi1, T, Fs)
x1 = 0;
t = [0:1/Fs:T];

for i=1:K
    x1 = x1 + A1(i)*sin((2*pi*f1(i)*t) + phi1(i)); 
end 
  
end