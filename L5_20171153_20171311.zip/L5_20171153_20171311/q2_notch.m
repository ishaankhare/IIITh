Fs = 1000;
T = 2;
t = 1:1/Fs:1000;
sumofsins = 1*sin(2*pi*50*t) + 1*sin(2*pi*100*t); 
y = filter( F, sumofsins);
figure(1);
plot(abs(fft(y)));
figure(2);
plot(abs(fft(sumofsins)));
