L=2500;
w = rand(1, L);
y = w.*2.*pi;
y1 = y-(pi);
a=1;
i=1;
W = 0.1;
x = randn(L, 1000);

summ = zeros(1,1000);
mean = zeros(1,1000);

for d=1:1000
    for j=1:L
        summ(1, d) = summ(1, d) + x(j, d);
    end
    mean(1, d) = summ(1, d)/L;
end

figure;
plot(mean);
k = 0;
mul = zeros(1000,1000);
inter = zeros(L, 1);
for j=1:1000
    for i=1:1000
        for k=1:L    
        inter(k, 1) = x(k,i) * x(k,j);
        end
        mul(j,i) = sum(inter)/L;
    end
end    

figure;
imagesc(mul);












