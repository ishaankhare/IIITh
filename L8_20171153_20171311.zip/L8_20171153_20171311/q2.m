er(10)=0; 
ber1(10)=0;
y(10)=0;
for z1=1:10
 
    size1 = 100;
    ma = randi(2, 1, size1*2) - randi(1, 1, size1*2);
    err = z1;
    urt = sqrt(err);
    mb = randi(2, 1, size1);
    
    for o=1:2:size1*2
        
        if ma(o) == 0 && ma(o+1) == 0   
            mb((o+1)/2) = urt;
        elseif ma(o) == 0 && ma(o+1) == 1
            mb((o+1)/2) = 1j*urt;
        elseif ma(o) == 1 && ma(o+1) == 1
            mb((o+1)/2) = -urt;
        elseif ma(o) == 1 && ma(o+1) == 0
            mb((o+1)/2) = -urt*1j;
        end    
        
    end

    mb2 = mb + randn(1, size1);    
    
    for r=1:size1
        if real(mb2(r)) > 0 && real(mb2(r)) > abs(imag(mb2(r)))   
            
        elseif imag(mb2(r)) > 0 && imag(mb2(r)) > abs(real(mb2(r))) 
            
        elseif real(mb2(r)) < 0 && real(mb2(r)) < abs(imag(mb2(r))) 
           
        elseif  imag(mb2(r)) < 0 && imag(mb2(r)) < abs(real(mb2(r))) 
        
        else 
            er(z1) = er(z1) + 1;
        end    
        
    
    end    
    
    ber1(z1) = er(z1)/size1;
    
end 

E1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
plot((E1), (ber1));



















 