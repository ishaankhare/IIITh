er(10) = 0;
ber(10) = 0; 
y(10) = 0;
for z=1:10

    size = 100000;
    m = randi(2, 1, size) - randi(1, 1, size);
    e = z;
    u = sqrt(e);
    m2 = randi(2, 1, size);

    for i=1:size
        if m(i)==1
            m2(i) = u;
        else
            m2(i) = u*(-1);
        end
    end    

    m1 = m2 + randn(1,size);

    for i=1:size
        if m1(i)>0
            m1(i) = 1;
        else
            m1(i) = 0;
        end    
    end    

    for y=1:size
        if m(y) ~= m1(y)
            er(z) = er(z)+1; 
        end    
    end    
 
    ber(z) = er(z)/size;

    disp(ber(z));
    
end

E = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
plot((E), (ber));




